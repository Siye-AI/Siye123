#!/bin/bash
print_helptext()
{
echo "Usage: shelfsorter [-p|-s {i|n|v|l|b|h}]"
echo "Used primarily for sorting furniture data which is read through stdin."
echo " -p        print data contents and exit"
echo "-s         sort by additional argument: id(i),"
echo "           name(n), weight(v),length(l)"
echo "            width(b), height(h), print data"
echo "           contents and exit"
echo "  --help display this help and exit"
}

sort_data()
{
IFS= read -r header
echo "$header"
sort -t $'\t' "$@"
}

format_table()
{
column -t -s $'\t' -R 3,4,5,6
}

if [ "$1" == "--help" ]; then
	print_helptext
	exit 0
fi

if [ "$1" == "-p" ]; then
	format_table
	exit 0
fi

if [ "$1" == "-s" ]; then
	case "$2" in
	 "i") sort_data -k1,1n | format_table ;;
	 "n") sort_data -k2,2  | format_table ;;
	 "v") sort_data -k3,3n | format_table ;;
	 "l") sort_data -k4,4n | format_table ;;
	 "b") sort_data -k5,5n | format_table ;;
	 "h") sort_data -k6,6n | format_table ;;
	 *)  print_helptext; exit 1 ;;
      esac
      exit 0
fi


echo "Använd --help som parameter"
exit 1
